import React, { useState } from "react";
import '../../estilos/EditarProducto.css';

const ProductoEditar = ({ producto, onGuardar, onClose }) => {
  const [productoEditado, setProductoEditado] = useState({
    id: producto.id,
    nombre: producto.nombre,
    precio: producto.precio,
    descripcion: producto.descripcion || "",
  });

  const gestionarCambio = (e) => {
    const { name, value } = e.target;
    setProductoEditado({ ...productoEditado, [name]: value });
  };

  const guardarCambios = (e) => {
    e.preventDefault();
    onGuardar(productoEditado); // Llama a la función de guardado con los datos editados
  };

  return (
    <div className="editar-producto">
      <h2>Editar Producto</h2>
      <form onSubmit={guardarCambios}>
        <label>Nombre:</label>
        <input
          type="text"
          name="nombre"
          value={productoEditado.nombre}
          onChange={gestionarCambio}
          required
        />

        <label>Precio (€):</label>
        <input
          type="number"
          name="precio"
          value={productoEditado.precio}
          onChange={gestionarCambio}
          required
        />

        <label>Descripción:</label>
        <textarea
          name="descripcion"
          value={productoEditado.descripcion}
          onChange={gestionarCambio}
        ></textarea>

        <button type="submit">Guardar Cambios</button>
        <button type="button" onClick={onClose}>Cancelar</button>
      </form>
    </div>
  );
};

export default ProductoEditar;
