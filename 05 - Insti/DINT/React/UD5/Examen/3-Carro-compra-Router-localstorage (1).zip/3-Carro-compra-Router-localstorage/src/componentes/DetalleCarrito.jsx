import { Link } from 'react-router-dom';
import '../estilos/DetalleCarrito.css';
import { reducirCantidad, incrementarCantidad } from '../herramientas/buscarProducto';



const DetalleCarrito = ({ productos, setProductos, total, setTotal }) => {


  function incrementar(producto) {
    // Actualizamos lista de productos
    setProductos(incrementarCantidad(productos, producto.nombre))
    //Actualiamos el total
    setTotal(parseInt(total) + parseInt(producto.precio));

  }
  return (
    <div className="container-detalle">
      <ul>
        <h2>Productos Seleccionados</h2>
        {productos.map((producto, index) => {
          return (

            <li key={index} className="producto-item">              
              <div className="producto-detalle">
                <span>
                  {producto.cantidad} x {producto.nombre} : {producto.precio}Є
                </span>              
                  <img src={producto.url} alt={producto.nombre} />              
              </div>

              {/* Botones para incrementar/reducir cantidad */}
              <div className="producto-acciones">
                <button
                  className="btn-reducir"                  
                >
                  -
                </button>
                <button
                  className="btn-incrementar"
                  onClick={() =>
                    incrementar(producto)
                  }
                >
                  +
                </button>
                <button
                  className="btn-consultar"
                  onClick={() =>
                    alert("Debe aparecer la información de un producto en un modal")
                  }
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                  </svg>
                </button>
              </div>
            </li>
          );
        })}
        <li className="total">Número de Elementos: {productos.length}</li>
      </ul>
    </div>
  );
};

export default DetalleCarrito;
