import React, { useState } from 'react';
import '../estilos/Administrador.css';
import ServicioInformacion from '../servicios/axios/ServicioInformacion';
import Modal from './Modal/Modal';
import ProductoEditar from './Modal/ProductoEditar';

function Administrador() {
  const [errores, setErrores] = useState({});
  const [informacion, setInformacion] = useState([]);
  const [productoSeleccionado, setProductoSeleccionado] = useState(null);
  
  const [modals, setModals] = useState({    
    editar: false,
  });

  const gestionarModal = (tipo, estado, producto = null) => {
    setModals({ ...modals, [tipo]: estado });    
    
    setProductoSeleccionado(producto);
    
  };


  const [form, setForm] = useState({
    nombre: '',
    precioMenor: '',
    precioMayor: '',
  });

  const gestionarCambio = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const validar = () => {
   
    alert("Cuidado, estás haciendo una búsqueda sin validar")

    return true

  };

  const enviarFormulario = (e) => {
    e.preventDefault();
    if (validar()) {
      if (form.nombre.trim() !== '') {
        ServicioInformacion.getPorNombre(form.nombre)
          .then((response) => setInformacion(response.data))
          .catch(() => alert('No se ha podido descargar la información...'));
      } else if (form.precioMenor.trim() !== '' || form.precioMayor.trim() !== '') {
        ServicioInformacion.getPorPrecio(form.precioMenor, form.precioMayor)
          .then((response) => setInformacion(response.data))
          .catch(() => alert('No se ha podido descargar la información...'));
      } 
    } 
  };

  const limpiarFormulario = () => {
    setForm({ nombre: '', precioMenor: '', precioMayor: '' });
    setErrores({});
    setInformacion([]);
  };


  const eliminarProducto = (id) => {
    const confirmar = window.confirm("¿Estás seguro de que deseas eliminar este producto?");
    if (confirmar) {
      ServicioInformacion.delete(id)
        .then(() => {
          setInformacion(informacion.filter(item => item.id !== id));
          alert("Producto eliminado correctamente.");
        })
        .catch(() => alert("Error al eliminar el producto."));
    }
  };
  const guardarProductoEditado = (productoEditado) => {
    ServicioInformacion.update(productoEditado.id, productoEditado)
      .then(() => {
        setInformacion(informacion.map(item =>
          item.id === productoEditado.id ? productoEditado : item
        ));
        setModals({ ...modals, editar: false }); // Cerrar modal
        alert("Producto actualizado correctamente.");
      })
      .catch(() => alert("Error al actualizar el producto."));
  };


  return (
    <>
      <div className="filters">
        <form onSubmit={enviarFormulario}>
          <label htmlFor="nombre">Nombre</label>
          <input id="nombre" type="text" name="nombre" value={form.nombre} onChange={gestionarCambio} placeholder="Escribe el nombre" />
         

          <label htmlFor="precioMenor">Precio Mínimo</label>
          <input id="precioMenor" type="text" name="precioMenor" value={form.precioMenor} onChange={gestionarCambio} placeholder="Importe Mínimo" />
         

          <label htmlFor="precioMayor">Precio Máximo</label>
          <input id="precioMayor" type="text" name="precioMayor" value={form.precioMayor} onChange={gestionarCambio} placeholder="Importe Máximo" />
         

          <button type="submit">Buscar</button>
          <button type="button" onClick={limpiarFormulario}>Limpiar</button>
        </form>
      </div>

      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Precio (€)</th>
            <th>URL</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {informacion.map((item, index) => (
            <tr key={index}>
              <td>{item.id}</td>
              <td>{item.nombre}</td>
              <td>{item.precio}</td>
              <td><a href="#">Ver Producto</a></td>
              <td className="actions">
                <button className="edit" onClick={() => gestionarModal("editar", true, item)}>Editar</button>               
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Botón para crear productos */}
      <button className="crear-producto-btn">
        Crear Nuevo Producto
      </button>

    
      <Modal isOpen={modals.editar} onClose={() => gestionarModal("editar", false)}>
        {productoSeleccionado && (
          <ProductoEditar
            producto={productoSeleccionado}
            onGuardar={guardarProductoEditado}
            onClose={() => gestionarModal("editar", false)}
          />
        )}
      </Modal>

    </>
  );
}

export default Administrador;
