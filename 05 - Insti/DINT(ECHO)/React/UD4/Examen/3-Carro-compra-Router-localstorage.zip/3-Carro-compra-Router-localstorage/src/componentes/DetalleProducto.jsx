import '../estilos/DetalleProducto.css';
import {buscarProducto} from "../herramientas/buscarProducto"
import { useParams } from 'react-router-dom';

const DetalleProducto = ({productos}) => {  

  const {nombre} = useParams()

  let productoInfo = buscarProducto(productos,nombre )

  return (
    <div className="container-detalle-producto">
      {productoInfo !== null ? (
        <div className="producto-info">
          <h1 className="producto-nombre">{productoInfo.nombre}</h1>
          <p className="producto-precio">{productoInfo.precio} Є</p>
          <img
            className="producto-imagen"
            src={productoInfo.url}
            alt={productoInfo.nombre}
          />
        </div>
      ) : (
        <h1 className="error-mensaje">No existe el producto indicado</h1>
      )}
    </div>
  );
  
};

export default DetalleProducto ;
