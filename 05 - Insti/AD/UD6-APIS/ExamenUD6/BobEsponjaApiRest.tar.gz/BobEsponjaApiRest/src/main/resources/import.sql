INSERT INTO personaje(nombre,descripción) VALUES('Bob Esponja','Vive en la piña debajo del mar');
INSERT INTO personaje(nombre,descripción) VALUES('Calamardo','Toca el clarinete');
INSERT INTO personaje(nombre,descripción) VALUES('Señor Cangrejo','Propietario de Crusty Crab');