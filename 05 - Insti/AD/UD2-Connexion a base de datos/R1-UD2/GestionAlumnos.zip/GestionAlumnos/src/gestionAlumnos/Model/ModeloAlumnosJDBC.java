package gestionAlumnos.Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ModeloAlumnosJDBC implements IModeloAlumnos {

	private static String cadenaConexion =  "jdbc:mysql://localhost:3306/instituto";
	private static String user = "dam2";
	private static String pass = "asdf.1234";
	
	public ModeloAlumnosJDBC() {
		
	}

	@Override
	public List<String> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Alumno getAlumnoPorDNI(String DNI) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean modificarAlumno(Alumno alumno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean eliminarAlumno(String DNI) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean crear(Alumno alumno) {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
